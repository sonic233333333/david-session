<h1 align="center"> This base was created by King Sam </h1>

<p align="center">
<img src="https://telegra.ph/file/7fba1ad2920b3f745b885.jpg" width="360" height="360"/>
</p>

<p align="center">
<a href="https://github.com/Samue-l1"><img title="Author" src="https://img.shields.io/badge/Dagger-Bot?style=for-the-badge&logo=whatsapp"></a>
<p/>
<p align="center">
<a href="https://github.com/Samue-l1?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/zetsubococaebom?label=Followers&style=social"></a>
<a href="https://github.com/Samue-l1/Dagger-Bot/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Samue-l1/Dagger-Bot?&style=social"></a>
<a href="https://github.com/Samue-l1/Dagger-Bot/network/members"><img title="Fork" src="https://img.shields.io/github/forks/zetsubococaebom/Zetsubo-Md?style=social"></a>
<a href="https://github.com/Samue-l1/Dagger-Bot/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/zetsubococaebom/Zetsubo-Md?label=Watching&style=social"></a>
</p>
</a>
</p>  
<h2 align="center">Guide For Those Of You Who Use Termux</h2>

## Install Several Packages And Run Bots

```csharp
> git clone https://github.com/Samue-l1/Dagger-Bot
> apt-get update -y
> apt-get upgrade -y
> apt-get install -y git
> sh wibu.sh
````

<h2 align="center">Guide For Panel Users</h2>

## 🖥 Go to panel and upload this Sc.

 📝 After that, extract or move it to a directory (container).

 ⌨ Use the following code to move into a container: "../"

 🖨 Then go to the console and press Start, and you will get a Qr code that will be linked to WhatsApp

<h2 align="center">Features</h2>

## How to deploy to heroku

```csharp
🦠| .You need to scan and get session using pair code
🦠| .Upload session to { Daggerses }
🦠| .Go to [Heroku](heroku.com) Login 
🦠| .Create a new app
🦠| .Add the Build packs Below 
🦠| .👇👇
```
# Instalasi
* [Pair code](https://replit.com/@pesguru02/Classic-Pairing)
* [Heroku](  https://heroku.com/deploy?template=https://github.com/Samue-l1/Samue-l1)
## Heroku Buildpack
```bash
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```





## Special Thanks to

* [WhiskeySockets](https://github.com/WhiskeySockets)

* [Mamang Adhiraj](https://github.com/adiwajshing)

* [King Sam](https://github.com/Samue-l1)

## Contact Me
  
* [Telegram](@k_i_n_g_s_a_m)
* [Whatsapp Direct Message](https://api.whatsapp.com/send?phone=+254104301695)
